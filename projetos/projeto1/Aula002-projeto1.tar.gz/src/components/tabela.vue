<template>
<div>
  <titulo titulo="Curso Vue.JS - Aula 02 - Exercicio 2" cor="red"></titulo>   
   <table id="styletabela" border="1">
  <tr>
    <th>Nome</th>
    <th>Cargo</th>
    <th>Unidade</th>
  </tr>
  <tr>
    <td>José</td>
    <td>Analista</td>
    <td>Tupis</td>
  </tr>
  <tr>
    <td>Maria</td>
    <td>Gerente</td>
    <td>Sede</td>
  </tr>
</table> 
</div>
</template>

<script>
export default {      

}
</script>

<style>
  #styletabela{
    width: 100%;    
    text-align: center;
    background-color:cornsilk;
    color: green;
    
  }
</style>