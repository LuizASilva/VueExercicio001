<template>
<div>
  <h3>Bem vindo ao Exercicio 3</h3>
  <br />
</div>

</template>

<script>
export default { 

   props: { 
    titulo: {
      type: String,
      default: "Home Default"
    }
    }
  };
</script>

  <style>
         
  </style>