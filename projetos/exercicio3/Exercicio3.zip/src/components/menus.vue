<template>
<div>
  
  <router-link :to="{name: 'home'}">Home</router-link> |
  <router-link :to="{name: 'tabela'}">Tabela</router-link> |
  <router-link :to="{name: 'formulario'}">Formulario</router-link>
</div>
</template>

<script>
    
</script>

<style>

</style>